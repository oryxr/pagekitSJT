# Minimal Theme

A very clean and simple theme great for blogging.