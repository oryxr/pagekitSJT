# Changelog

## 1.0.2 (June 30, 2016)

### Removed
- Removed system messages

## 1.0.1 (April 13, 2016)

### Fixed
- Fixed article divider

## 1.0.0 (April 7, 2016)

- Initial release
